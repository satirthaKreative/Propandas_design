<!DOCTYPE html>
<html lang="en">
   	@include('frontend.include.head')
<body id="go-top">
	@include('frontend.include.header')
    @yield('content')
    @include('frontend.include.footer')
    @yield('pagewishjs')
</body>
</html>