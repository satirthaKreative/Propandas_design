$(document).ready(function() {
    $('.multi-cate').select2();
});