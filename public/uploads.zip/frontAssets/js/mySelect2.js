$(document).ready(function() {
    $('.county_list').select2();
});