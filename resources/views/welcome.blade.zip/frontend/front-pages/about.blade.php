@extends('layouts.frontendLayouts.app')
@section('content')
	<section class="inner-banner">
	   <div class="container">
	      <h1>About Us</h1>
	      <div class="breadcum-top">
	         <ul class="breadcrumb">
	            <li><a href="#">Home</a></li>
	            <li>About Us </li>
	         </ul>
	      </div>
	   </div>
	</section>
	<!-- end of inner-banner -->

	<section class="about-part">
	   <div class="container">
	      <div class="row">
	         <div class="col-sm-5">
	          <div class="abt-shape">

	          </div>            
	         </div>
	         <div class="col-sm-7 my-about">
	            
	            <!-- <p>We believe that law has to be accessible for everyone. While our world is full ofbrilliant   lawyers,   the   traditional   law   firm   structure   makes  it   sometimes   hardlyaccessible for many people, especially for small businesses. Many small companiescannot afford to pay hourly rates that are largely composed of overhead costs forinflated law firm structures and are rather interested in a having narrowly definedlegal issues resolved in an efficient way. On the other hand, a big part of highlycapable lawyers find themselves stuck in the hierarchies of the corporate legalworld with few opportunities for their professional self-fulfillment.</p>            
	            <p>ProPandas mission is to streamline the process of hiring a lawyer through avoidingcostly law firm structures and digitalizing the way how clients and lawyers canmeet.</p>   -->          
	         </div>
	      </div>
	   </div>
	</section>  <!-- end of about-part -->
	
@endsection